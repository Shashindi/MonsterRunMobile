import express from "express";
import { 
  register, 
  login, 
  getUserProfile, 
  updateUserProfile, 
  deleteUserAccount,
  getAllUsers
} from "../Controllers/UserController.js";

const router = express.Router();

// Auth routes
router.post("/register", register);
router.post("/login", login);

// Profile routes
router.get("/", getAllUsers);
router.get("/profile/:userId", getUserProfile);
router.put("/profile/:userId", updateUserProfile);
router.delete("/profile/:userId", deleteUserAccount);

export default router;
