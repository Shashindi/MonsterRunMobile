import React, { useState, useEffect } from 'react';
import { 
  Container, Row, Col, Card, CardHeader, CardBody, Button, 
  Modal, ModalHeader, ModalBody, ModalFooter, Form, FormGroup, 
  Label, Input, Table, Badge, Spinner, Alert, InputGroup, 
  InputGroupText, Dropdown, DropdownToggle, DropdownMenu, 
  DropdownItem, Pagination, PaginationItem, PaginationLink 
} from 'reactstrap';
import axios from 'axios';
import { 
  FaPlus, FaEdit, FaTrash, FaSearch, FaFilePdf, 
  FaSortAmountDown, FaFileDownload, FaCalendarAlt 
} from 'react-icons/fa';
import { toast } from 'react-toastify';

const FinanceManagement = () => {
  const [finances, setFinances] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [modal, setModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [selectedFinance, setSelectedFinance] = useState(null);
  const [sortDropdownOpen, setSortDropdownOpen] = useState(false);
  const [reportModal, setReportModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState([]);
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    limit: 10
  });
  const [sortOption, setSortOption] = useState('date-desc');
  const [formData, setFormData] = useState({
    type: 'expense',
    amount: '',
    category: '',
    description: '',
    date: new Date().toISOString().split('T')[0]
  });
  const [reportData, setReportData] = useState({
    startDate: '',
    endDate: '',
    type: ''
  });
  const [generatingReport, setGeneratingReport] = useState(false);

  // Toggle modals
  const toggleModal = () => setModal(!modal);
  const toggleDeleteModal = () => setDeleteModal(!deleteModal);
  const toggleSortDropdown = () => setSortDropdownOpen(!sortDropdownOpen);
  const toggleReportModal = () => setReportModal(!reportModal);

  // Reset form data
  const resetFormData = () => {
    setFormData({
      type: 'expense',
      amount: '',
      category: '',
      description: '',
      date: new Date().toISOString().split('T')[0]
    });
    setSelectedFinance(null);
  };

  // Fetch finance records
  const fetchFinances = async (page = 1) => {
    setLoading(true);
    setError(null);
    
    try {
      let url = `http://localhost:4000/api/finance?page=${page}&limit=${pagination.limit}`;
      
      // Add search query if it exists
      if (searchQuery) {
        url += `&search=${searchQuery}`;
      }
      
      // Add sort option
      const [sortField, sortOrder] = sortOption.split('-');
      url += `&sort=${sortField}&order=${sortOrder}`;
      
      const response = await axios.get(url);
      
      if (response.data && response.data.data) {
        setFinances(response.data.data);
        setPagination({
          currentPage: page,
          totalPages: response.data.pagination.pages,
          limit: pagination.limit
        });
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch finance records');
      toast.error(err.response?.data?.message || 'Failed to fetch finance records');
    } finally {
      setLoading(false);
    }
  };

  // Fetch categories
  const fetchCategories = async () => {
    try {
      const response = await axios.get('http://localhost:4000/api/finance/categories');
      if (response.data && response.data.data) {
        setCategories(response.data.data);
      }
    } catch (err) {
      console.error('Failed to fetch categories:', err);
    }
  };

  // Initial data load
  useEffect(() => {
    fetchFinances();
    fetchCategories();
  }, []);

  // Handle page change
  const handlePageChange = (page) => {
    fetchFinances(page);
  };

  // Handle form input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle report form input change
  const handleReportInputChange = (e) => {
    const { name, value } = e.target;
    setReportData({ ...reportData, [name]: value });
  };

  // Handle search input
  const handleSearch = () => {
    fetchFinances(1);
  };

  // Handle sort change
  const handleSortChange = (option) => {
    setSortOption(option);
    setTimeout(() => fetchFinances(1), 0);
  };

  // Open modal for creating new finance record
  const openCreateModal = () => {
    resetFormData();
    toggleModal();
  };

  // Open modal for editing finance record
  const openEditModal = (finance) => {
    setSelectedFinance(finance);
    setFormData({
      type: finance.type,
      amount: finance.amount,
      category: finance.category,
      description: finance.description || '',
      date: new Date(finance.date).toISOString().split('T')[0]
    });
    toggleModal();
  };

  // Open confirmation modal for deleting finance record
  const openDeleteModal = (finance) => {
    setSelectedFinance(finance);
    toggleDeleteModal();
  };

  // Open report generation modal
  const openReportModal = () => {
    setReportData({
      startDate: '',
      endDate: '',
      type: ''
    });
    toggleReportModal();
  };

  // Create new finance record
  const createFinance = async () => {
    setLoading(true);
    try {
      const response = await axios.post('http://localhost:4000/api/finance', formData);
      toast.success('Finance record created successfully');
      toggleModal();
      fetchFinances(pagination.currentPage);
      fetchCategories();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create finance record');
    } finally {
      setLoading(false);
    }
  };

  // Update finance record
  const updateFinance = async () => {
    setLoading(true);
    try {
      const response = await axios.put(`http://localhost:4000/api/finance/${selectedFinance._id}`, formData);
      toast.success('Finance record updated successfully');
      toggleModal();
      fetchFinances(pagination.currentPage);
      fetchCategories();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update finance record');
    } finally {
      setLoading(false);
    }
  };

  // Delete finance record
  const deleteFinance = async () => {
    setLoading(true);
    try {
      await axios.delete(`http://localhost:4000/api/finance/${selectedFinance._id}`);
      toast.success('Finance record deleted successfully');
      toggleDeleteModal();
      fetchFinances(pagination.currentPage);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete finance record');
    } finally {
      setLoading(false);
    }
  };

  // Generate and download PDF report
  const generateReport = async () => {
    try {
      setGeneratingReport(true);
      
      // Create the URL with report parameters
      let url = 'http://localhost:4000/api/finance/report?';
      if (reportData.type) url += `type=${reportData.type}&`;
      if (reportData.startDate) url += `startDate=${reportData.startDate}&`;
      if (reportData.endDate) url += `endDate=${reportData.endDate}&`;
      
      // Show loading toast
      toast.info('Generating finance report, please wait...', {
        autoClose: 3000
      });
      
      // Use axios to get the PDF as a blob
      const response = await axios.get(url, {
        responseType: 'blob'
      });
      
      // Create a URL for the blob
      const fileURL = window.URL.createObjectURL(new Blob([response.data]));
      
      // Create a filename with date details
      const now = new Date();
      const dateStr = now.toLocaleDateString().replace(/\//g, '-');
      const timeStr = now.toLocaleTimeString().replace(/:/g, '-');
      const filename = `Finance_Report_${dateStr}_${timeStr}.pdf`;
      
      // Create a temporary link element to trigger download
      const fileLink = document.createElement('a');
      fileLink.href = fileURL;
      fileLink.setAttribute('download', filename);
      document.body.appendChild(fileLink);
      
      // Trigger the download
      fileLink.click();
      
      // Clean up
      window.URL.revokeObjectURL(fileURL);
      document.body.removeChild(fileLink);
      
      // Close the modal
      toggleReportModal();
      
      // Show success toast
      toast.success('Finance report generated successfully!');
    } catch (err) {
      toast.error('Failed to generate report. Please try again.');
      console.error('Report generation error:', err);
    } finally {
      setGeneratingReport(false);
    }
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedFinance) {
      updateFinance();
    } else {
      createFinance();
    }
  };

  // Handle report form submission
  const handleReportSubmit = (e) => {
    e.preventDefault();
    generateReport();
  };

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'LKR'
    }).format(amount);
  };

  // Get type badge color
  const getTypeBadgeColor = (type) => {
    return type === 'income' ? 'success' : 'danger';
  };

  return (
    <Container fluid className="p-4">
      <Row className="mb-4">
        <Col>
          <h2 className="mb-0">Finance Management</h2>
          <p className="text-muted">Manage your income and expenses</p>
        </Col>
      </Row>

      <Row className="mb-4">
        <Col md={7} className="mb-3 mb-md-0">
          <InputGroup>
            <Input
              type="text"
              placeholder="Search by category, description, type, or amount..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button color="primary" onClick={handleSearch}>
              <FaSearch /> Search
            </Button>
          </InputGroup>
        </Col>
        <Col md={5} className="d-flex justify-content-md-end">
          <Dropdown isOpen={sortDropdownOpen} toggle={toggleSortDropdown} className="me-2">
            <DropdownToggle color="secondary" caret>
              <FaSortAmountDown /> Sort
            </DropdownToggle>
            <DropdownMenu end>
              <DropdownItem onClick={() => handleSortChange('date-desc')}>
                Date (Newest First)
              </DropdownItem>
              <DropdownItem onClick={() => handleSortChange('date-asc')}>
                Date (Oldest First)
              </DropdownItem>
              <DropdownItem onClick={() => handleSortChange('amount-desc')}>
                Amount (Highest First)
              </DropdownItem>
              <DropdownItem onClick={() => handleSortChange('amount-asc')}>
                Amount (Lowest First)
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>

          <Button color="success" onClick={openReportModal} className="me-2">
            <FaFilePdf /> Generate Report
          </Button>
          
          <Button color="primary" onClick={openCreateModal}>
            <FaPlus /> Add Finance
          </Button>
        </Col>
      </Row>

      <Card className="shadow">
        <CardHeader className="bg-white">
          <h5 className="mb-0">Finance Records</h5>
        </CardHeader>
        <CardBody>
          {loading && (
            <div className="text-center py-5">
              <Spinner color="primary" />
              <p className="mt-2">Loading finance records...</p>
            </div>
          )}

          {error && !loading && (
            <Alert color="danger">
              {error}
            </Alert>
          )}

          {!loading && !error && finances.length === 0 && (
            <div className="text-center py-5">
              <p className="mb-0">No finance records found.</p>
              <Button color="primary" size="sm" className="mt-3" onClick={openCreateModal}>
                Add your first finance record
              </Button>
            </div>
          )}

          {!loading && !error && finances.length > 0 && (
            <>
              <div className="table-responsive">
                <Table className="align-middle" striped hover>
                  <thead className="bg-light">
                    <tr>
                      <th>Date</th>
                      <th>Type</th>
                      <th>Category</th>
                      <th>Description</th>
                      <th>Amount</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {finances.map((finance) => (
                      <tr key={finance._id}>
                        <td>{new Date(finance.date).toLocaleDateString()}</td>
                        <td>
                          <Badge color={getTypeBadgeColor(finance.type)} pill>
                            {finance.type.charAt(0).toUpperCase() + finance.type.slice(1)}
                          </Badge>
                        </td>
                        <td>{finance.category}</td>
                        <td>{finance.description || '—'}</td>
                        <td className={`fw-bold ${finance.type === 'income' ? 'text-success' : 'text-danger'}`}>
                          {formatCurrency(finance.amount)}
                        </td>
                        <td>
                          <Button
                            color="info"
                            size="sm"
                            outline
                            className="me-2"
                            onClick={() => openEditModal(finance)}
                            title="Edit Record"
                          >
                            <FaEdit />
                          </Button>
                          <Button
                            color="danger"
                            size="sm"
                            outline
                            onClick={() => openDeleteModal(finance)}
                            title="Delete Record"
                          >
                            <FaTrash />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </div>
              
              {/* Pagination */}
              {pagination.totalPages > 1 && (
                <div className="d-flex justify-content-center mt-4">
                  <Pagination>
                    <PaginationItem disabled={pagination.currentPage === 1}>
                      <PaginationLink 
                        first 
                        onClick={() => handlePageChange(1)}
                      />
                    </PaginationItem>
                    <PaginationItem disabled={pagination.currentPage === 1}>
                      <PaginationLink 
                        previous 
                        onClick={() => handlePageChange(pagination.currentPage - 1)}
                      />
                    </PaginationItem>

                    {/* Page numbers */}
                    {[...Array(pagination.totalPages).keys()].map(page => {
                      // Show only 5 page numbers at a time
                      if (
                        page + 1 === 1 ||
                        page + 1 === pagination.totalPages ||
                        (page + 1 >= pagination.currentPage - 1 &&
                          page + 1 <= pagination.currentPage + 1)
                      ) {
                        return (
                          <PaginationItem 
                            key={page} 
                            active={page + 1 === pagination.currentPage}
                          >
                            <PaginationLink onClick={() => handlePageChange(page + 1)}>
                              {page + 1}
                            </PaginationLink>
                          </PaginationItem>
                        );
                      } else if (
                        page + 1 === pagination.currentPage - 2 ||
                        page + 1 === pagination.currentPage + 2
                      ) {
                        return (
                          <PaginationItem key={page} disabled>
                            <PaginationLink>...</PaginationLink>
                          </PaginationItem>
                        );
                      }
                      return null;
                    })}

                    <PaginationItem disabled={pagination.currentPage === pagination.totalPages}>
                      <PaginationLink 
                        next 
                        onClick={() => handlePageChange(pagination.currentPage + 1)}
                      />
                    </PaginationItem>
                    <PaginationItem disabled={pagination.currentPage === pagination.totalPages}>
                      <PaginationLink 
                        last 
                        onClick={() => handlePageChange(pagination.totalPages)}
                      />
                    </PaginationItem>
                  </Pagination>
                </div>
              )}
            </>
          )}
        </CardBody>
      </Card>

      {/* Create/Edit Finance Modal */}
      <Modal isOpen={modal} toggle={toggleModal} size="lg">
        <ModalHeader toggle={toggleModal} className="bg-light">
          {selectedFinance ? 'Edit Finance Record' : 'Add New Finance Record'}
        </ModalHeader>
        <Form onSubmit={handleSubmit}>
          <ModalBody>
            <Row>
              <Col md={6}>
                <FormGroup>
                  <Label for="type" className="fw-bold">Type*</Label>
                  <Input
                    type="select"
                    name="type"
                    id="type"
                    value={formData.type}
                    onChange={handleInputChange}
                    required
                    className="shadow-sm"
                  >
                    <option value="income">Income</option>
                    <option value="expense">Expense</option>
                  </Input>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Label for="amount" className="fw-bold">Amount*</Label>
                  <InputGroup className="shadow-sm">
                    <InputGroupText>LKR: </InputGroupText>
                    <Input
                      type="number"
                      name="amount"
                      id="amount"
                      placeholder="Enter amount"
                      value={formData.amount}
                      onChange={handleInputChange}
                      min="0.01"
                      step="0.01"
                      required
                    />
                  </InputGroup>
                </FormGroup>
              </Col>
            </Row>
            
            <Row>
              <Col md={6}>
                <FormGroup>
                  <Label for="category" className="fw-bold">Category*</Label>
                  <Input
                    type="text"
                    name="category"
                    id="category"
                    placeholder="e.g., Ingredient Purchase, Cake Sale"
                    value={formData.category}
                    onChange={handleInputChange}
                    list="categoryOptions"
                    required
                    className="shadow-sm"
                  />
                  <datalist id="categoryOptions">
                    {categories.map((category, index) => (
                      <option key={index} value={category} />
                    ))}
                  </datalist>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Label for="date" className="fw-bold">Date*</Label>
                  <Input
                    type="date"
                    name="date"
                    id="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    required
                    className="shadow-sm"
                  />
                </FormGroup>
              </Col>
            </Row>
            
            <FormGroup>
              <Label for="description" className="fw-bold">Description</Label>
              <Input
                type="textarea"
                name="description"
                id="description"
                placeholder="Enter description or notes"
                value={formData.description}
                onChange={handleInputChange}
                rows="3"
                className="shadow-sm"
              />
            </FormGroup>
          </ModalBody>
          <ModalFooter className="bg-light">
            <Button color="secondary" onClick={toggleModal} className="shadow-sm">
              Cancel
            </Button>
            <Button color="primary" type="submit" disabled={loading} className="shadow-sm">
              {loading ? (
                <>
                  <Spinner size="sm" className="me-2" />
                  {selectedFinance ? 'Updating...' : 'Creating...'}
                </>
              ) : (
                selectedFinance ? 'Update' : 'Create'
              )}
            </Button>
          </ModalFooter>
        </Form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={deleteModal} toggle={toggleDeleteModal}>
        <ModalHeader toggle={toggleDeleteModal} className="bg-danger text-white">
          Confirm Delete
        </ModalHeader>
        <ModalBody>
          <p>Are you sure you want to delete this finance record?</p>
          <p>This action cannot be undone.</p>
          {selectedFinance && (
            <div className="mt-3 p-3 bg-light rounded shadow-sm">
              <p className="mb-1">
                <strong>Type:</strong>{' '}
                <Badge color={getTypeBadgeColor(selectedFinance.type)} pill>
                  {selectedFinance.type.charAt(0).toUpperCase() + selectedFinance.type.slice(1)}
                </Badge>
              </p>
              <p className="mb-1">
                <strong>Amount:</strong> {formatCurrency(selectedFinance.amount)}
              </p>
              <p className="mb-1">
                <strong>Category:</strong> {selectedFinance.category}
              </p>
              <p className="mb-1">
                <strong>Date:</strong> {new Date(selectedFinance.date).toLocaleDateString()}
              </p>
              {selectedFinance.description && (
                <p className="mb-0">
                  <strong>Description:</strong> {selectedFinance.description}
                </p>
              )}
            </div>
          )}
        </ModalBody>
        <ModalFooter className="bg-light">
          <Button color="secondary" onClick={toggleDeleteModal}>
            Cancel
          </Button>
          <Button color="danger" onClick={deleteFinance} disabled={loading}>
            {loading ? <Spinner size="sm" /> : 'Delete'}
          </Button>
        </ModalFooter>
      </Modal>

      {/* Report Generation Modal */}
      <Modal isOpen={reportModal} toggle={toggleReportModal}>
        <ModalHeader toggle={toggleReportModal} className="bg-success text-white">
          <FaFilePdf className="me-2" /> Generate Finance Report
        </ModalHeader>
        <Form onSubmit={handleReportSubmit}>
          <ModalBody>
            <p className="mb-3">Select options for your finance report:</p>
            
            <FormGroup>
              <Label for="reportType" className="fw-bold">Type</Label>
              <Input
                type="select"
                name="type"
                id="reportType"
                value={reportData.type}
                onChange={handleReportInputChange}
                className="shadow-sm"
              >
                <option value="">All Types</option>
                <option value="income">Income Only</option>
                <option value="expense">Expense Only</option>
              </Input>
            </FormGroup>
            
            <Row>
              <Col md={6}>
                <FormGroup>
                  <Label for="startDate" className="fw-bold">Start Date</Label>
                  <Input
                    type="date"
                    name="startDate"
                    id="startDate"
                    value={reportData.startDate}
                    onChange={handleReportInputChange}
                    className="shadow-sm"
                  />
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Label for="endDate" className="fw-bold">End Date</Label>
                  <Input
                    type="date"
                    name="endDate"
                    id="endDate"
                    value={reportData.endDate}
                    onChange={handleReportInputChange}
                    className="shadow-sm"
                  />
                </FormGroup>
              </Col>
            </Row>
            
            <Alert color="info" className="mt-3 mb-0">
              <div className="d-flex align-items-center">
                <FaCalendarAlt className="me-2" size={20} />
                <div>
                  <strong>Report Details:</strong>
                  <p className="mb-0 small">
                    Your report will include all finance records{reportData.type ? ` of type "${reportData.type}"` : ''}{' '}
                    {reportData.startDate && reportData.endDate 
                      ? `from ${new Date(reportData.startDate).toLocaleDateString()} to ${new Date(reportData.endDate).toLocaleDateString()}`
                      : 'across all dates'}.
                  </p>
                </div>
              </div>
            </Alert>
          </ModalBody>
          <ModalFooter className="bg-light">
            <Button color="secondary" onClick={toggleReportModal}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              color="success" 
              disabled={generatingReport}
              className="d-flex align-items-center shadow"
            >
              {generatingReport ? (
                <>
                  <Spinner size="sm" className="me-2" />
                  Generating...
                </>
              ) : (
                <>
                  <FaFileDownload className="me-2" />
                  Download Report
                </>
              )}
            </Button>
          </ModalFooter>
        </Form>
      </Modal>
    </Container>
  );
};

export default FinanceManagement;

